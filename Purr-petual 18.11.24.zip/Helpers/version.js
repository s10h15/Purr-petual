const version = "18.11.24";

document.title += " " + version;